
package javaapplicationuas;

import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class DataBuku extends javax.swing.JFrame {

    public DataBuku() {
        initComponents();
        table();
        
    }
    
    private void setHargaBuku(){
       int harga = 0;
       int pilihan = tJudul.getSelectedIndex();
       switch(pilihan){
           case 1:
               harga = 79000;
               break;
           case 2:
               harga = 69000;
               break;
           case 3:
                harga = 89000;
                break;
           case 4:
               harga = 74000;
               break;
           case 5:
               harga = 69000;
               break;
           case 6:
               harga = 124000;
               break;
       }
       tHarga.setText("" + harga);
    }
    
     void hapus(){
          
         tTanggal.setText(null);
         tJudul.setEditable(true);
         tHarga.setText(null);
         tSA.setText(null);
         tBM.setText(null);
         tBK.setText(null);
         tSAkhir.setText(null);
        }
     
      public void table(){
        DefaultTableModel tbl = new DefaultTableModel();
       
        tbl.addColumn("Tanggal");
        tbl.addColumn("Judul Buku");
        tbl.addColumn("Harga");
        tbl.addColumn("Stok Awal");
        tbl.addColumn("Buku Masuk");
        tbl.addColumn("Buku Keluar");
        tbl.addColumn("Stok Akhir");
        
        try{
            Statement st = (Statement) Koneksi.configDB().createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM data_buku");
            
            while(rs.next()){
                tbl.addRow(new Object[]{
                   
                    rs.getString("Tanggal"),
                    rs.getString("Judul_Buku"),  
                    rs.getString("Harga"),
                    rs.getString("Stok_Awal"),
                    rs.getString("Buku_Masuk"),
                    rs.getString("Buku_Keluar"),
                    rs.getString("Stok_Akhir"),
                });
                tabel2.setModel(tbl);
            }
            JOptionPane.showMessageDialog(null, "Koneksi Berhasil");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "koneksi gagal" + e.getMessage());
        }
        
    }


    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField3 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tambah = new javax.swing.JButton();
        ubah = new javax.swing.JButton();
        hapus = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabel2 = new javax.swing.JTable();
        kembali = new javax.swing.JButton();
        simpan = new javax.swing.JButton();
        tHarga = new javax.swing.JTextField();
        tSA = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        tBM = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        tBK = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        tSAkhir = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        tTanggal = new javax.swing.JTextField();
        tJudul = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();

        jTextField3.setText("jTextField3");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel8.setText("jLabel8");

        jLabel9.setText("jLabel9");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Data Buku");

        jLabel2.setText("Judul Buku");

        jLabel3.setText("Harga");

        jLabel4.setText("Stok Awal");

        tambah.setText("Tambah");
        tambah.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tambahMouseClicked(evt);
            }
        });

        ubah.setText("Ubah");
        ubah.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ubahMouseClicked(evt);
            }
        });

        hapus.setText("Hapus");
        hapus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hapusMouseClicked(evt);
            }
        });

        tabel2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Tanggal", "Judul Buku", "Harga", "Stok Awal", "Buku Masuk", "Buku Keluar", "Stok Akhir"
            }
        ));
        tabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabel2);

        kembali.setText("Kembali");
        kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kembaliActionPerformed(evt);
            }
        });

        simpan.setText("Simpan");
        simpan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                simpanMouseClicked(evt);
            }
        });

        jLabel6.setText("Buku Masuk");

        jLabel7.setText("Rp");

        jLabel10.setText("Buku Keluar");

        jLabel11.setText("Stok Akhir");

        jLabel5.setText("Tanggal");

        tJudul.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Pilih -", "Apa yang Benar, Bukan Siapa yang Benar", "Humaira & Alfarizi", "Indonesia Bagian dari Desa Saya", "Kalau Kamu Ikan, Jangan ikut Lomba Terbang", "Tuhan ada di Hatimu", "Untuk Kamu yang Ingin Menjadi Baik", " " }));
        tJudul.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tJudulActionPerformed(evt);
            }
        });

        jButton1.setText("=");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(kembali))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(103, 103, 103)
                                .addComponent(tambah)
                                .addGap(18, 18, 18)
                                .addComponent(ubah)
                                .addGap(18, 18, 18)
                                .addComponent(hapus)
                                .addGap(18, 18, 18)
                                .addComponent(simpan))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(39, 39, 39)
                                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(89, 89, 89)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel2)
                                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addGap(69, 69, 69))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(60, 60, 60)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addGap(18, 18, 18)
                                        .addComponent(tHarga))
                                    .addComponent(tSA, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tJudul, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tTanggal, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton1)
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(tSAkhir, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(tBK, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(tBM, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))))))
                        .addGap(0, 220, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 551, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(kembali)
                .addGap(1, 1, 1)
                .addComponent(jLabel1)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tTanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tJudul, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tHarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tSA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tBM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(tBK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(tSAkhir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 1, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tambah)
                    .addComponent(ubah)
                    .addComponent(hapus)
                    .addComponent(simpan))
                .addGap(35, 35, 35)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void kembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kembaliActionPerformed
       
        MenuAdmin ma = new MenuAdmin();
        ma.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_kembaliActionPerformed

    private void tambahMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tambahMouseClicked
        try{
            String sql = "INSERT INTO data_buku VALUES ('" + tTanggal.getText() + "','" + tJudul.getSelectedItem() + "','" + tHarga.getText() + "','" + tSA.getText() + "','" + tBM.getText() + "','" + tBK.getText() + "','" + tSAkhir.getText() + "')";
            Connection con = (Connection)Koneksi.configDB();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Berhasil Ditambahkan");          
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Gagal Ditambahkan" + e.getMessage());
        }
    }//GEN-LAST:event_tambahMouseClicked

    private void ubahMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ubahMouseClicked
        try{
            String sql = "UPDATE data_buku SET Tanggal='" + tTanggal.getText() + "',Judul_Buku='" + tJudul.getSelectedItem()+ "',Harga='" + tHarga.getText() + "',Stok_Awal='" + tSA.getText() + "',Buku_Masuk='" + tBM.getText() + "',Buku_Keluar='" + tBK.getText() + "',Stok_Akhir ='" + tSAkhir.getText() + "' WHERE Tanggal = '" +tTanggal.getText()+ "'";
            Connection con = (Connection)Koneksi.configDB();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Berhasil DiEdit");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Gagal DiEdit");
        }
    }//GEN-LAST:event_ubahMouseClicked

    private void hapusMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hapusMouseClicked
        try{
            String sql = "DELETE FROM data_buku WHERE Tanggal ='" + tTanggal.getText()+ "'";
            Connection con = (Connection)Koneksi.configDB();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Berhasil Dihapus");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Gagal Dihapus");
        }
    }//GEN-LAST:event_hapusMouseClicked

    private void simpanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_simpanMouseClicked
        try{
            String sql = "SELECT * FROM data_buku WHERE Tanggal ='" + tTanggal.getText()+ "'";
            Connection con = (Connection) Koneksi.configDB();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        table();
        hapus();       
    }//GEN-LAST:event_simpanMouseClicked

    private void tabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel2MouseClicked
         int baris = tabel2.rowAtPoint(evt.getPoint());
        
        String tanggal = tabel2.getValueAt(baris, 0).toString();
        tTanggal.setText(tanggal);
        String judul = tabel2.getValueAt(baris, 1).toString();
        tJudul.setSelectedItem(judul);
        String harga = tabel2.getValueAt(baris, 2).toString();
        tHarga.setText(harga);
        String stoka = tabel2.getValueAt(baris, 3).toString();
        tSA.setText(stoka);
        String bukum = tabel2.getValueAt(baris, 4).toString();
        tBM.setText(bukum);
        String bukuk = tabel2.getValueAt(baris, 5).toString();
        tBK.setText(bukuk);
        String stokak = tabel2.getValueAt(baris, 6).toString();
        tSAkhir.setText(stokak);
    }//GEN-LAST:event_tabel2MouseClicked

    private void tJudulActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tJudulActionPerformed
        setHargaBuku();
    }//GEN-LAST:event_tJudulActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try{
            int stokawal = Integer.parseInt(tSA.getText());
            int bukumasuk = Integer.parseInt(tBM.getText());
            int bukukeluar = Integer.parseInt(tBK.getText());
            tSAkhir.setText(""+(stokawal+bukumasuk-bukukeluar));
        }catch(NumberFormatException e){
            tSAkhir.setText("0");
            
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DataBuku().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton hapus;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JButton kembali;
    private javax.swing.JButton simpan;
    private javax.swing.JTextField tBK;
    private javax.swing.JTextField tBM;
    private javax.swing.JTextField tHarga;
    private javax.swing.JComboBox<String> tJudul;
    private javax.swing.JTextField tSA;
    private javax.swing.JTextField tSAkhir;
    private javax.swing.JTextField tTanggal;
    private javax.swing.JTable tabel2;
    private javax.swing.JButton tambah;
    private javax.swing.JButton ubah;
    // End of variables declaration//GEN-END:variables
}
