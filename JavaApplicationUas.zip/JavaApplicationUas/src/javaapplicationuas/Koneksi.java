package javaapplicationuas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Koneksi{
    
    private static Connection MySQLConfig;
    
    public static Connection configDB() throws SQLException {
       
        try {
            String db = "jdbc:mysql://localhost:3306/admin";
            String user = "root";
            String pass = "";
            
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            MySQLConfig = DriverManager.getConnection(db, user, pass);
        }catch (SQLException e){
            System.out.println("Koneksi gagal" + e.getMessage());
        }
        return MySQLConfig;
    }
}
       

