
package javaapplicationuas;

import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class DataPenjualan extends javax.swing.JFrame {
   
    public DataPenjualan() {
        initComponents();
        table();
    }
    
    private void setHargaBuku(){
       int harga = 0;
       int pilihan = tJudul.getSelectedIndex();
       switch(pilihan){
           case 1:
               harga = 79000;
               break;
           case 2:
               harga = 69000;
               break;
           case 3:
                harga = 89000;
                break;
           case 4:
               harga = 74000;
               break;
           case 5:
               harga = 69000;
               break;
           case 6:
               harga = 124000;
               break;
       }
       tHarga.setText("" + harga);    
    }
    
     void hapus(){
          
         jTanggal.setText(null);
         tJudul.setEditable(true);
         tHarga.setText(null);
         tJumlah.setText(null);
         tTotal.setText(null);
     }
     
     public void table(){
        DefaultTableModel tbl = new DefaultTableModel();
       
        tbl.addColumn("Tanggal");
        tbl.addColumn("Judul Buku");
        tbl.addColumn("Harga Satuan ");
        tbl.addColumn("Jumlah");
        tbl.addColumn("Sub Total");
        
        try{
            Statement st = (Statement) Koneksi.configDB().createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM data_penjualan");
            
            while(rs.next()){
                tbl.addRow(new Object[]{
                   
                    rs.getString("Tanggal"),
                    rs.getString("Judul_Buku"),  
                    rs.getString("Harga_Satuan"),
                    rs.getString("Jumlah"),
                    rs.getString("Sub_Total"),
                });
                tabel3.setModel(tbl);
            }
            JOptionPane.showMessageDialog(null, "Koneksi Berhasil");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "koneksi gagal" + e.getMessage());
        }
        
     }


    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel3 = new javax.swing.JTable();
        tHarga = new javax.swing.JTextField();
        tambah = new javax.swing.JButton();
        ubah = new javax.swing.JButton();
        hapus = new javax.swing.JButton();
        jKembali = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tJumlah = new javax.swing.JTextField();
        tambahjumlah = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        tTotal = new javax.swing.JTextField();
        tJudul = new javax.swing.JComboBox<>();
        jTanggal = new javax.swing.JTextField();
        simpan = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Data Penjualan");

        jLabel3.setText("Judul Buku");

        jLabel4.setText("Tanggal Pembelian");

        tabel3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, "", null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Tanggal Pembelian", "Judul Buku", "Harga Satuan", "Jumlah", "Sub Total"
            }
        ));
        tabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel3MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabel3);

        tambah.setText("Tambah");
        tambah.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tambahMouseClicked(evt);
            }
        });

        ubah.setText("Ubah");
        ubah.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ubahMouseClicked(evt);
            }
        });

        hapus.setText("Hapus");
        hapus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hapusMouseClicked(evt);
            }
        });

        jKembali.setText("Kembali");
        jKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jKembaliActionPerformed(evt);
            }
        });

        jLabel5.setText("Harga Satuan");

        jLabel6.setText("Jumlah");

        tambahjumlah.setText("=");
        tambahjumlah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahjumlahActionPerformed(evt);
            }
        });

        jLabel7.setText("Sub Total");

        tJudul.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Pilih -", "Apa yang Benar, Bukan Siapa yang Benar", "Humaira & Alfarizi", "Indonesia Bagian dari Desa Saya", "Kalau Kamu Ikan, Jangan ikut Lomba Terbang", "Tuhan ada di Hatimu", "Untuk Kamu yang Ingin Menjadi Baik", " " }));
        tJudul.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tJudulActionPerformed(evt);
            }
        });

        simpan.setText("Simpan");
        simpan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                simpanMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 670, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jKembali))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(109, 109, 109)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel3))
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(tHarga, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(tJumlah, javax.swing.GroupLayout.DEFAULT_SIZE, 123, Short.MAX_VALUE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(tambahjumlah))
                                .addComponent(tTotal))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jTanggal, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tJudul, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(24, 24, 24))
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(tambah)
                .addGap(18, 18, 18)
                .addComponent(ubah)
                .addGap(18, 18, 18)
                .addComponent(hapus)
                .addGap(18, 18, 18)
                .addComponent(simpan)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jKembali)))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4)
                    .addComponent(jTanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tJudul, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tHarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 93, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tambah)
                            .addComponent(ubah)
                            .addComponent(hapus)
                            .addComponent(simpan))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tJumlah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tambahjumlah))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jKembaliActionPerformed
       
        MenuAdmin ma = new MenuAdmin();
        ma.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jKembaliActionPerformed

    private void tJudulActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tJudulActionPerformed
        setHargaBuku();
    }//GEN-LAST:event_tJudulActionPerformed

    private void tambahjumlahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahjumlahActionPerformed
        try{
            int hargasatuan = Integer.parseInt(tHarga.getText());
            int jumlahbuku = Integer.parseInt(tJumlah.getText());
            tTotal.setText(""+(hargasatuan*jumlahbuku));
        }catch(NumberFormatException e){
            tTotal.setText("0");
            
        }
          
    }//GEN-LAST:event_tambahjumlahActionPerformed

    private void tambahMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tambahMouseClicked
        try{
            String sql = "INSERT INTO data_penjualan VALUES ('" + jTanggal.getText() + "','" + tJudul.getSelectedItem() + "','" + tHarga.getText() + "','" + tJumlah.getText() + "','" + tTotal.getText() + "')";
            Connection con = (Connection)Koneksi.configDB();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Berhasil Ditambahkan");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Gagal ditambahkan" + e.getMessage());
        }
    }//GEN-LAST:event_tambahMouseClicked

    private void ubahMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ubahMouseClicked
         try{
            String sql = "UPDATE data_penjualan SET Tanggal='" + jTanggal.getText() + "',Judul_Buku='" + tJudul.getSelectedItem() + "',Harga_Satuan='" + tHarga.getText() + "',Jumlah='" + tJumlah.getText() + "',Sub_Total='" + tTotal.getText() + "'WHERE Tanggal = '" + jTanggal.getText()+ "'";
            Connection con = (Connection)Koneksi.configDB();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Berhasil Diubah");
         }catch(Exception e){
             JOptionPane.showMessageDialog(null, "Gagal diubah" + e.getMessage());
         }
    }//GEN-LAST:event_ubahMouseClicked

    private void hapusMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hapusMouseClicked
        try{
            String sql = "DELETE FROM data_penjualan WHERE Tanggal ='" + jTanggal.getText()+ "'";
            Connection con = (Connection)Koneksi.configDB();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Berhasil Dihapus");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Gagal Dihapus");
        
        }                                  
    }//GEN-LAST:event_hapusMouseClicked

    private void simpanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_simpanMouseClicked
        try{
            String sql = "SELECT * FROM data_penjualan WHERE Tanggal ='" + jTanggal.getText()+ "'";
            Connection con = (Connection) Koneksi.configDB();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        table();
        hapus();   
    }//GEN-LAST:event_simpanMouseClicked

    private void tabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel3MouseClicked
        int baris = tabel3.rowAtPoint(evt.getPoint());
        
        String tanggal = tabel3.getValueAt(baris, 0).toString();
        jTanggal.setText(tanggal);
        String judul = tabel3.getValueAt(baris, 1).toString();
        tJudul.setSelectedItem(judul);
        String harga = tabel3.getValueAt(baris, 2).toString();
        tHarga.setText(harga);
        String jumlah = tabel3.getValueAt(baris, 3).toString();
        tJumlah.setText(jumlah);
        String total = tabel3.getValueAt(baris, 4).toString();
        tTotal.setText(total);
    }//GEN-LAST:event_tabel3MouseClicked

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DataPenjualan().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton hapus;
    private javax.swing.JButton jKembali;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTanggal;
    private javax.swing.JButton simpan;
    private javax.swing.JTextField tHarga;
    private javax.swing.JComboBox<String> tJudul;
    private javax.swing.JTextField tJumlah;
    private javax.swing.JTextField tTotal;
    private javax.swing.JTable tabel3;
    private javax.swing.JButton tambah;
    private javax.swing.JButton tambahjumlah;
    private javax.swing.JButton ubah;
    // End of variables declaration//GEN-END:variables
}
//data penjualan = data yang terjual 
